package net.com.wipro;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin("http://localhost:4200")
public interface ProductRepository extends JpaRepository<Product, Long>{

	
	
	@Query(value="select p from Product p where  p.brand = ?1")
    public	List<Product> findByBrand(@Param("brand")String brand);
	
	@Query(value="select p from Product p where  p.price <?1 ")
    public	List<Product> findByPrice(@Param("price")int price);
  
	@Query(value="select p from Product p where  p.price >?1")
    public	List<Product> findByGreaterPrice(@Param("price")int price);
	
}
