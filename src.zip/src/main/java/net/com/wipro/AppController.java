package net.com.wipro;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class AppController {

	@Autowired
	private ProductService service; 
	
	
	@GetMapping("/")
	public String getHomePage(Model model) 
	{
		
		return "carsHomePage";
	}
	
	@GetMapping("/brandSelection")
	public String getProducts(@ModelAttribute("product") Product product,Model model) {
		
		List<Product> listOfProducts = service.listAllProducts();
		model.addAttribute("product",product);
		model.addAttribute("listOfProducts", listOfProducts);
		
		return "brandSelection";
	}
	
	@RequestMapping(value="/listByBrand",method=RequestMethod.POST)
	public String validateBrand(@ModelAttribute("product") @Valid Product product, Errors errors, Model model,String brand) {
    List<Product> listOfProducts = service.listAll(brand);
		System.out.println(listOfProducts.size());
		model.addAttribute("listOfProducts", listOfProducts);
		
		if(errors.hasErrors()) {
			return "brandSelection";
		}
		else {
		return "list";
		}
	}
	
	
	
	
	@RequestMapping(value = "/SortByPrice")
	public String showPricePage() {
		
		return "SortByPrice";
	}
	
	@GetMapping("/listByPrice")
	public String validateByPrice(Model model, @Param("price") int price) {
		List<Product> listOfProducts = service.getByPrice(price);
		model.addAttribute("listOfProducts", listOfProducts);
		
		return "list";
	}
	
	
	@GetMapping("/successPage")
	public String showSuccessPage(Product product, Model model,@Param("brand") String brand) {
		List<Product> listProducts = service.listAll(brand);
		model.addAttribute("listProducts", listProducts);
		return "success";
		
		
	}
	
	
}
