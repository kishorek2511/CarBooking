package net.com.wipro;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ProductService {

	@Autowired
	private ProductRepository repo;
	
	public List<Product> listAll(String brand) {
		if(brand!=null) {
			return repo.findByBrand(brand);
		}
		return repo.findAll();
	}
	
	public List<Product> listAllProducts(){
		return repo.findAll();
	}
	
	public void save(Product product) {
		repo.save(product);
	}
	
	public List<Product> getByPrice(int price){
		if(price==500000) {
		return repo.findByPrice(price);
		}
		else {
			return repo.findByGreaterPrice(price);
		}
		
	}
	
}
